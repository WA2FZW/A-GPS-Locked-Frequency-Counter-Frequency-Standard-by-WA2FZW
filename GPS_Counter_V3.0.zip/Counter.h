/*
 *	Counter.h - Contains definitions of a few things used by the "GPS_COunter" program.
 */

#ifndef	_COUNTER_H_
#define	_COUNTER_H_							// Prevent double include


/*
 *	This is a macro that is used to determine the number of elements in an array. It figures
 *	that out by dividing the total size of the array by the size of a single element. This is
 *	how we will calculate the number of entries in the "gates" array!
 */

#define ELEMENTS(x)		( sizeof ( x ) / sizeof ( x[0] ))


/*
 *	Define the serial communication port speeds. We'll run the serial monitor at
 *	115,200 bits per second. The GPS module defaults to 9,600 baud which I believe
 *	can be changed by sending a message to it, but I won't fool with that until I'm
 *	sure everything else works.
 */

#define	USB_SPEED	115200			// For sending data to a PC
#define	GPS_SPEED	  9600			// For listening to the GPS module


/*
 *	Define the GPIO pins used for various things. The names match the names used on
 *	the schematic where applicable.
 *
 *	Serial ports; only the GPS ones are actually used in the code, and note the TX/RX
 *	names for them are how they are designated on the GPS module, so we actually receive
 *	data from the GPS on the "TX" pin:
 */

#define	USB_RX		 0			// USB Receive pin
#define	USB_TX		 1			// USB transmit pin
#define	GPS_RX		 4			// GPS transmit pin (receive on the GPS module)
#define	GPS_TX		 5			// GPS receive pin (transmit on the GPS module)

#define	GPS_1PPS	 2			// 1 Pulse per second indicator (interrupt enabled)

#define	MODE_SW		10			// Frequency counter/standard switch.


/*
 *	Define the PCF8574 pins used to read the SN74LV8154 data bits. The order is a bit
 *	goofy as it made it easier to design the PCB. 
 */

#define	Y0		 0				// LSB
#define	Y1		 1
#define	Y2		 2
#define	Y3		 3
#define	Y4		 7
#define	Y5		 6
#define	Y6		 5
#define	Y7		 4				// MSB

#define	PCF_I2C_ADDR	0x38	// I2C address of the PCF8574A


/*
 *	SN74LV8154 byte readout select pins:
 */

#define	GAL		 9				// Counter "A" low byte
#define	GAU		 8				// Counter "A" high byte
#define	GBL		 7				// Counter "B" low byte
#define	GBU		 6				// Counter "B" high byte


/*
 *	Other SN74LV8154 pins:
 */

#define	RCLK	11				// Fake 1PPS signal from the processor
#define	CCLR	A0				// Clear counter resister


/*
 *	These pins are for the two I2C busses. The PCF8574 and the display are on the
 *	standard bus. TJ's Si5351 code doesn't use the "Wire" library and if the Si5351
 *	is put on the same bus with other devices, nothing works! Thus we use a separate
 *	I2C bus for the Si5351.
 */

#define	SDA		A4							// The standard I2C bus used for
#define	SCL		A5							// The display and the PCF8574

#define	SI_SDA	A2							// Separate I2C bus for the Si5351
#define	SI_SCL	A3

#define	SI_I2C_ADDR	0x60					// I2C address of the Si5351 module


/*
 *	These definitions are for the liquid crystal display:
 */

#define	LCD_ADDRESS	0x27						// Some of mine are 0x3F
#define	LCD_WIDTH	  20
#define	LCD_HEIGHT	   4


/*
 *	These definitions are related to the optional function button. If the symbol "GATE_BUTTON"
 *	is defined, parts of the code are compiled in order to handle it. "GATE_BUTTON" allows one
 *	to change the gate time. The choices are 1S, 2S, 5S and 10S. If the symbol is not defined
 *	(i.e., commented out), the code to cycle through the gate times is not compiled. If you
 *	don't have the button installed, comment out the #define.
 *
 *	The "BUTTON_READ_TIME" symbol defines how often we actually check the button as it is
 *	operated at human speed, we don't have to actually look every time through the main loop.
 */

	#define	GATE_BUTTON								// Gate time select button is installed

	#define	BUTTON_READ_TIME 25UL					// How often to check it

	#define	GATE_BUTTON_PIN	   12					// Arduino pin number assignments for the button


/*
 *	One can optionally install a LED to indicate that the gate time has elapsed. The Arduino
 *	pin assignment happens to also be the one for the LED on the board. To install an outboard
 *	LED, connect the LED through a 220 ohm resistor between pin D13 and ground. If I make newer
 *	PCBs, I'll put the resistor on the board.
 */

	#define	GATE_LED_PIN	   13					// Gate time LED pin assignment
	#define	GATE_LED_TIME	 50UL					// Leave it on for 50 microseconds


/*
 *	All the following stuff is needed for the Si5351 library, which is a modification
 *	of the software originally created by TJ Ubeo for his digital VFO and is used in
 *	the VFO I developed along with VK3PE and G3ZQC and the Si5351 calibration program.
 *
 *	You might need to change some of the following items.
 *
 *	Some Si5351 modules use a 27MHz crystal instead of the ore common 25MHz one. If the
 *	module you are using is one with the 27MHz crystal, change the definition of SI_ZTAL
 *	appropriately.
 *
 *	If you know the correction factor for your particular Si5351, you can set the
 *	value of SI_CAL. Doing so will start the Si5351 on or very close to the desired
 *	frequency.
 */

	#define	SI_XTAL		25000000UL				// Could also be 27000000UL
//	#define	SI_CAL		       0				// If you know the right number - Change it!
	#define	SI_CAL	   -3520					// This is for my unit!


/*
 *	The "STANDARD_FREQ" is the frequency that will pe output on CLK0 of the Si5351
 *	when the function switch is in the "Frequency Standard" position. It can be changed
 *	to suit your needs, but note the counter chip is only rated to 40MHz.
 */

//	#define	STANDARD_FREQ	10000000UL			// 10MHz
//	#define	STANDARD_FREQ	29000000UL			// 29MHz - 5th harmonic = 145MHz
	#define	STANDARD_FREQ	20750000UL			// 20.75MHz - 7th harmonic = 145.25MHz


/*
 *	If you mess with any of the following, bad things might happen! These define
 *	how we configure the frequency standard output (CLK0). The "Carrier
 *	Oscillator" nomenclature is from the VFO program as CLK0 and CLK1 are used
 *	for that purpose in the VFO.
 *
 *	Unlike we did in the VFO program, we don't define a fixed setting for the 
 *	carrier oscillator mode. That is because we will turn it on when the mode
 *	switch is in the "Frequency Standard" position, but turn it off when the
 *	switch is in the "Frequency Counter" position.
 */

#define	C_OSC_OFF		0					// No carrier oscillator
#define	C_OSC_CLK0		1					// CLK0 only
#define	C_OSC_CLK1		2					// CLK1 only
#define	C_OSC_QUAD		3					// Quadrature mode (both clocks 90 degrees out of phase)
#define	C_OSC_QUAD_R	4					// Reverse quadrature mode


/*
 *	Definitions for the mode switch:
 */

#define	COUNT_MODE		LOW					// Counter mode
#define	STANDARD_MODE	HIGH				// Frequency standard mode


/*
 *	These definitions are for bits in the status indicator:
 */

#define	STARTUP			0x01				// System is in startup (or restart) mode
#define	CALIBRATE		0x02				// Si5351 is being recalibrated


/*
 *	The following are miscellaneous things used to control the program status.
 *
 *	"TIMEOUT" is specified in microseconds.
 */

#define	TIMEOUT	   1000010UL						// 1.00001 seconds to check 1PPS pulse

#define	GOOD_LOCK  GPS_READ_COUNT + 2				// Number of consecutive 1PPS pulses
													// to assure we are locked & loaded

#define	MAX_ERROR		0UL							// If the difference between the actual
													// frequency and the STANDARD_FREQ is
													// greater then MAX_ERROR, we re-calibrate.

#define	GPS_READ_COUNT	8							// Number of SN74LV8154 readings to be averaged
													// When in frequency standard mode


/*
 *	These three definitions are for stuff related to the "Adafruit_GPS" library.
 *
 *	The "PMTK_FACTORY_RESET" defines a message that can be sent to the GPS module to
 *	restore the factory settings. A bunch of other standard commands are defined in
 *	the "Adafruit_GPS.h" file itself.
 *
 *	If the "USE_NEMA" symbol is set to "false", the program will not bother reading or
 *	writing NMEA data or GPS commands.
 *
 *	If "GPS_ECHO" is set to true, the program will display the received NMEA messages
 *	on the serial monitor.
 */

#define	PMTK_FACTORY_RESET	"$PMTK314,-1*04"		// GPS Factory reset message
#define	USE_NMEA			true					// False if not using the NMEA data
#define	GPS_ECHO			false					// True to echo the NMEA messages

#endif
