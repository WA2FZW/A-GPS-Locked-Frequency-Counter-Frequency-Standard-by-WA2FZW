/*
 *	Where.h - Contains definitions of a few things used by the "Where_MI" program.
 */

#ifndef	_WHERE_H_
#define	_WHERE_H_							// Prevent double include


/*
 *	Define the serial communication port speeds. We'll run the serial monitor at
 *	115,200 bits per second. The GPS module defaults to 9,600 baud which I believe
 *	can be changed by sending a message to it, but I won't fool with that until I'm
 *	sure everything else works.
 */

#define	USB_SPEED	115200			// For sending data to a PC
#define	GPS_SPEED	  9600			// For listening to the GPS module


/*
 *	Define the GPIO pins used for various things. The names match the names used on
 *	the schematic where applicable.
 *
 *	Serial ports; only the GPS ones are actually used in the code, and note the TX/RX
 *	names for them are how they are designated on the GPS module, so we actually receive
 *	data from the GPS on the "TX" pin:
 */

#define	USB_RX		 0			// USB Receive pin
#define	USB_TX		 1			// USB transmit pin
#define	GPS_RX		 4			// GPS transmit pin (receive on the GPS module)
#define	GPS_TX		 5			// GPS receive pin (transmit on the GPS module)

#define	GPS_1PPS	 2			// 1 Pulse per second indicator (interrupt enabled)


/*
 *	I2C Bus for the diaplay
 */

#define	SDA		A4							// The standard I2C bus used for
#define	SCL		A5							// The display and the PCF8574


/*
 *	These definitions are for the liquid crystal display:
 */

#define	LCD_ADDRESS	0x27
#define	LCD_WIDTH	  20
#define	LCD_HEIGHT	   4


/*
 *	These two definitions are for stuff related to the "Adafruit_GPS" library.
 *
 *	The "PMTK_FACTORY_RESET" defines a message that can be sent to the GPS module to
 *	restore the factory settings. A bunch of other standard commands are defined in
 *	the "Adafruit_GPS.h" file.
 *
 *	If "GPS_ECHO" is set to true, the program will display the received NMEA messages
 *	on the serial monitor.
 */

#define	PMTK_FACTORY_RESET	"$PMTK314,-1*04"		// GPS Factory reset message

#define	GPS_ECHO false

#endif
